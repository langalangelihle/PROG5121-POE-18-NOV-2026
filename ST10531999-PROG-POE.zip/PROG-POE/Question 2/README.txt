# Question 2 - Mattress Sales GUI

## What this project is about
Question 2 is the GUI version of the sales thing. Instead of printing everything in the console like Q1, this one is a form where you type in a customer name, pick a product, type in a price, and then click PROCESS.

It then calculates:
- VAT (15%)
- Commission (5%)
- Total (Price + VAT + Commission)

And it shows it in a popup message and also saves it to a file called `data.txt`.

## How to run it in NetBeans

1. Open Apache NetBeans
2. File > Open Project > Select this folder (Question2)
3. Make sure the Main Class is set to `question2.ProductForm`
4. Right click on `ProductForm.java` > Run File
5. The form will open

To test it, use the example from the question:
- Customer Name: Joe Bloggs
- Product: Cozy Nights Monarch
- Product Price: 3500
- Click PROCESS

You should get:
- VAT: R 525.0
- COMMISSION: R 175.0
- TOTAL: R 4200.0

To run the tests:
Right click on `ProductCalculationsTest.java` > Run File. All 3 tests should pass.

## Files in this project

- `ProductCalculations.java` - This class does all the maths. It has 3 methods: getVAT, getCommission, getTotal. I kept all the calculations here so the form is not messy.
- `ProductForm.java` - This is the GUI. It has the textfields, combo box, buttons, menu, and the code for the PROCESS button. It also writes to data.txt.
- `ProductCalculationsTest.java` - Unit tests for Q2.6. Tests VAT, Commission and Total with 3500.

## How I built it

I started with ProductCalculations first because that was the easiest part. It's just 3 methods with percentages, so I got that done and tested quickly.

Then I did the form. I dragged / coded the labels, textfields, combo box and buttons. The combo box has the 3 products:
- Cozy Nights Monarch
- Restonic Barbados
- Sealy Phuket

After the form was showing, I added the PROCESS button logic - get the price, call the calculation methods, show the JOptionPane message, then write to data.txt.

Menu was last. I added File > Process, Clear, Exit. Process does the same as the PROCESS button, Clear clears the fields, Exit closes the app.

## Difficulties I faced

This one was also stressful because I was running out of time after Q1, and GUI is more fiddly than console.

1. **The form layout kept messing up.** My labels and textfields were not lining up. At first everything was on top of each other. I had to use GridLayout(5,2) to get it to look like the screenshot. It took a few tries before it looked neat.

2. **Getting the numbers right.** I kept mixing up VAT and Commission percentages. I wrote 0.15 for commission by mistake at first, so my total was wrong. When I tested with 3500 I was getting a total that didn't match the screenshot (4200). I had to go back and check - VAT is 15%, Commission is 5%. Once I fixed that, it matched exactly.

3. **data.txt was not appearing.** I clicked PROCESS and it showed the message, but I couldn't find data.txt anywhere. I thought my code was broken. Then I realised NetBeans was creating it inside the Question2 project folder, not on my Desktop. I had to look in the project folder to find it. Also, I forgot to use `true` in FileWriter at first, so it was overwriting instead of appending. Fixed that.

4. **Menu confusion.** I didn't realise the menu items had to do the same thing as the buttons. I made the menu but clicking Process did nothing. I had to add the same ActionListener to the menu item as the button. Same for Clear.

5. **Unit tests again.** Same problem as Q1, I picked the wrong JUnit version first. I deleted and recreated with JUnit 5. And my first test failed because I used assertEquals without the delta for doubles. I had to add the 0.01 at the end.

6. **Time pressure.** By the time I got to Q2 I was already tired from Q1. I was rushing and I kept forgetting to save before running, so NetBeans was running the old version and I thought my fixes weren't working. I had to slow down and do one thing, save, run, check, then move on.

## What I learned

- How to make a simple GUI in Java with Swing - JFrame, JLabel, JTextField, JComboBox, JButton, JMenuBar.
- How to separate logic from the GUI - calculations in one class, form in another. It makes it easier to test.
- How to write to a text file with FileWriter.
- How to use JOptionPane to show messages.

## Example data.txt output

After clicking PROCESS with Joe Bloggs / Cozy Nights Monarch / 3500, data.txt looks like this:
