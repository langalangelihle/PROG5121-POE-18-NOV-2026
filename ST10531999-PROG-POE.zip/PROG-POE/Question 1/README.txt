# Question 1 - Mattress Sales Report

## What this project is about
This is Question 1 for my assignment. It's a console app that prints out a sales report for 3 mattress products over 3 months - March, April and May.

The products are:
1. Cozy Nights Monarch
2. Restonic Barbados
3. Sealy Phuket

For each product it shows the sales for each month and then the total sales.

## How to run it in NetBeans

1. Open Apache NetBeans
2. File > Open Project > Select this folder (Question1)
3. Make sure the Main Class is set to `question1.ProductReport` or whatever I named it - actually in my project its `question1.Main` - just run the file with the main method
4. Right click > Run File
5. The report will print in the Output window

To run the tests:
Right click on the test file > Run File. Both tests should pass.

## Files in this project

- `IProducts.java` - This is the interface. It has the methods for getting the product name, sales, and total.
- `Product.java` - This class implements the interface. It stores the name and the 3 months sales and calculates the total.
- `PrintProduct.java` - This one does the printing. It takes a product and prints it in the table format.
- `Main.java` / `ProductReport.java` - This is where I create the 3 products and call PrintProduct to show the report.
- `ProductTest.java` - Unit tests for Q1.4

## How I built it

Honestly I started by just trying to get the report to print right first, because the table in the question was confusing me. I made the Product class with the 3 months as separate fields, then I added a method to add them up for the total.

After that worked, I went back and made the interface because I kept forgetting that Q1.2 said the Product class MUST implement IProducts. I had to refactor a bit.

PrintProduct was the last part. At first I was printing everything from Main and it looked messy, so I moved all the printing into PrintProduct like the question asked.

## Difficulties I faced

I'm not gonna lie, this one gave me stress because I had very little time.

1. **The interface confused me at first.** I kept mixing up what goes in the interface vs what goes in the class. I thought I had to put the actual calculations in the interface. I had to re-read Q1.2 like 3 times before I realised the interface is just the method names, the real code lives in Product.java. Once I got that, it clicked.

2. **NetBeans errors.** I kept getting "package does not exist" and "cannot find symbol" errors. It was because I created the classes in different packages by mistake. I had to delete them and recreate them all in the same package `question1`. That wasted like 20 minutes.

3. **Formatting the table.** Getting the columns to line up in the console was annoying. My first output was all over the place. I had to play around with spaces and `printf` until it looked close to the screenshot in the question. It's still not 100% perfect but it's readable and the numbers are correct.

4. **Unit tests.** I had never used JUnit before in NetBeans. It kept asking me for JUnit 4 or 5 and I picked the wrong one first and the import was failing. I had to delete the test and recreate it with JUnit 5 and then it worked. The test for the total sales was failing at first because I was using the wrong expected value - I miscalculated by hand.

5. **Time pressure.** I was doing this with very little time left, so I was rushing and making silly mistakes like forgetting semicolons and forgetting to save files before running. I had to slow down, do one class at a time, run it, and then move to the next one. That actually saved me time in the end.

## What I learned

- How interfaces actually work - they are like a contract, the class has to follow it.
- How to split code into different classes instead of putting everything in main.
- How to write a simple unit test and why it's useful - it caught my calculation mistake.

## Example Output
